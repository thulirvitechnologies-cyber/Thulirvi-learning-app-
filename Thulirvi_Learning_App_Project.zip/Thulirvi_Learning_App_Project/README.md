# Thulirvi Learning Android App (starter MVP)

This is a free-to-build Android WebView app with a local LMS-style interface. It includes course and internship cards, the existing registration form, a basic task tracker stored on the device, learning-material placeholders, and support links.

## Important configuration before sharing with students
Open `app/src/main/assets/index.html` and replace:
- `PASTE_DRIVE_FOLDER_LINK_HERE` with your public/read-only Google Drive learning-material folder link.
- `PASTE_ASSIGNMENT_FORM_LINK_HERE` with your assignment Google Form.
- `PASTE_WHATSAPP_COMMUNITY_LINK_HERE` with your WhatsApp Community invite link.
- Review the course fees, durations and certificate eligibility text before publishing.

The existing application form is prefilled as:
https://forms.gle/f1Zge2UTWKHHqhhC9

## Build APK free using GitHub Actions
1. Create a new **public** GitHub repository named `thulirvi-learning-app` (public repositories get GitHub Actions minutes at no charge within GitHub's applicable limits).
2. Upload the files and folders in this project, preserving the folder structure, including `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab and choose **Build Thulirvi Learning APK**.
4. Tap **Run workflow** if available. Wait for the run to finish successfully.
5. Open the completed workflow run, scroll to **Artifacts**, and download `Thulirvi-Learning-APK`.
6. Extract the ZIP on your phone. The APK inside is `app-debug.apk`. Install only after reviewing Android's install warning and your device's package permissions.

## Current limitations
- This MVP is not a secure account-based LMS. There is no server-side login, synced progress, payment verification, admin dashboard or automated certificate issuing.
- Progress checkboxes are saved only on that device/browser storage and may be lost if app data is cleared.
- Never store payment proofs, passwords, identity documents or sensitive student records in the APK.
- Do not treat a checkbox as proof that a student completed a course.
- A debug APK is suitable for a small pilot only. Play Store publication requires a release build, signing, policy compliance and Google Play developer registration.
